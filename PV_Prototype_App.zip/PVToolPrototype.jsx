'use client';
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function PVToolPrototype() {
  const [ppa, setPpa] = useState(45);
  const [capex, setCapex] = useState(85000000);
  const [yieldValue, setYieldValue] = useState(1800);
  const [revenue, setRevenue] = useState([]);

  const calculate = () => {
    const years = [...Array(25).keys()].map(i => i + 1);
    const degradation = 0.005;
    const capacity = 100; // MWp
    const results = years.map(year => {
      const adjustedYield = yieldValue * Math.pow(1 - degradation, year - 1);
      const annualRevenue = adjustedYield * capacity * ppa;
      return { year, revenue: annualRevenue };
    });
    setRevenue(results);
  };

  return (
    <div className="grid grid-cols-1 gap-4 p-6 md:grid-cols-2">
      <Card>
        <CardContent className="space-y-4 pt-6">
          <div>
            <Label>PPA Price ($/MWh)</Label>
            <Input type="number" value={ppa} onChange={e => setPpa(parseFloat(e.target.value))} />
          </div>
          <div>
            <Label>CapEx Total (US$)</Label>
            <Input type="number" value={capex} onChange={e => setCapex(parseFloat(e.target.value))} />
          </div>
          <div>
            <Label>Yield (kWh/kWp/year)</Label>
            <Input type="number" value={yieldValue} onChange={e => setYieldValue(parseFloat(e.target.value))} />
          </div>
          <Button onClick={calculate}>Calcular Receita</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6 h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={revenue}>
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="revenue" stroke="#8884d8" name="Receita (US$)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}